﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp44
{
    [Serializable]
    class Work
    {
        public string Rabota;
        public string Edizm;
        public int Obyom_rabot;
        public int Cenazaedizm;
        public Work (string rabota, string edizm, int obyom_rabot, int cenazaedizm)
        {
            Rabota = rabota;
            Edizm = edizm;
            Obyom_rabot = obyom_rabot;
            Cenazaedizm = cenazaedizm;
          
        }

    }
}
