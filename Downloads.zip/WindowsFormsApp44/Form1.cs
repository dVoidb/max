﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp44
{

    
    public partial class Form1 : Form
    {
        Nabor_works Nabor;
        public Form1()
        {
            InitializeComponent();
            Nabor = new Nabor_works();
        }
        private void UpdateTable()
        {
            dataGridView1.Rows.Clear();
            dataGridView1.RowCount = Nabor.Works.Count;
            for (int i=0; i < Nabor.Works.Count; i++)
            {
                dataGridView1.Rows[i].Cells[0].Value = Nabor.Works[i].Rabota;
                dataGridView1.Rows[i].Cells[1].Value = Nabor.Works[i].Edizm;
                dataGridView1.Rows[i].Cells[2].Value = Nabor.Works[i].Obyom_rabot;
                dataGridView1.Rows[i].Cells[3].Value = Nabor.Works[i].Cenazaedizm;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string rabota = textBox1.Text;
            string edizm = textBox2.Text;
            int obyom_rabot = Convert.ToInt32(textBox3.Text);
            int cenazaedizm = Convert.ToInt32(textBox4.Text);
            Nabor.DobavitWork(rabota, edizm, obyom_rabot, cenazaedizm);
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            UpdateTable();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Nabor.SaveInFile("Works.dat");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Nabor = Nabor_works.PoluchitNaborIzFile("Works.dat");
            UpdateTable();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int vsegoObyom_rabot = 0, vsegoCenazaedizm = 0, vsegoStoimostrabot = 0, postroke = 0;
            for (int i=0; i < Nabor.Works.Count;i++)
            {
                postroke = Nabor.Works[i].Obyom_rabot * Nabor.Works[i].Cenazaedizm;
                dataGridView1.Rows[i].Cells[4].Value = postroke;
                vsegoObyom_rabot += Nabor.Works[i].Obyom_rabot;
                vsegoCenazaedizm += Nabor.Works[i].Cenazaedizm;
                vsegoStoimostrabot += postroke;

            }
            int index = dataGridView1.Rows.Add();
            dataGridView1.Rows[index].Cells[2].Value = vsegoObyom_rabot;
            dataGridView1.Rows[index].Cells[3].Value = vsegoCenazaedizm;
            dataGridView1.Rows[index].Cells[4].Value = vsegoStoimostrabot;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int i = dataGridView1.SelectedRows[0].Index;
            dataGridView1.Rows.RemoveAt(i);
        }
    }
}
