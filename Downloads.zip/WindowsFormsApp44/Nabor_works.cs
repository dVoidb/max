﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp44
{
    [Serializable]
    class Nabor_works
    {
        public List<Work> Works;
        public Nabor_works()
        {
            Works = new List<Work>();
        }
        public void DobavitWork(string rabota, string edizm, int obyom_rabot, int cenazaedizm)
        {
            Work work = new Work(rabota, edizm, obyom_rabot, cenazaedizm);
                Works.Add(work);
        }
        public void SaveInFile(string path)
        {
            FileStream stream = new FileStream(path, FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(stream, this);
            stream.Close();
        }
        public static Nabor_works PoluchitNaborIzFile(string path)
        {
            Nabor_works nabor;
            FileStream stream = new FileStream(path, FileMode.Open);
            BinaryFormatter formatter = new BinaryFormatter();
            nabor = (Nabor_works)formatter.Deserialize(stream);
            stream.Close();
            return nabor;
        }
    }
}
