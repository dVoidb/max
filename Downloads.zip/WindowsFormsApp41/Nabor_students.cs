﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp41
{
    [Serializable]
    class Nabor_students
    {
        public List<Student> Students;
        public Nabor_students()
        {
            Students = new List<Student>();
        }
        public void DobavitStudenta(int number, string fio, int total, int reason)
        {
            Student student = new Student(number, fio, total, reason);
            Students.Add(student);
        }
        public void SochranitVFile(string path)
        {
            FileStream stream = new FileStream(path, FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(stream, this);
            stream.Close();
        }
        public static Nabor_students PoluchitNaborIzFile(string path)
        {
            Nabor_students nabor;
            FileStream stream = new FileStream(path, FileMode.Open);
            BinaryFormatter formatter = new BinaryFormatter();
            nabor = (Nabor_students)formatter.Deserialize(stream);
            stream.Close();
            return nabor;
        }
    }
}
