﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp41
{
    [Serializable]
    class Student
    {
        public int Number;
        public string FIO;
        public int skipped_total;
        public int skipped_reason;
       
        public Student(int number, string fio, int total, int reason)
        {
            Number = number;
            FIO = fio;
            skipped_total = total;
            skipped_reason = reason;
        }
    }
}
