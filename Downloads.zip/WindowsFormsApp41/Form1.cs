﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp41
{
    public partial class Form1 : Form
    {
        Nabor_students Nabor;
        public Form1()
        {
            InitializeComponent();
            Nabor = new Nabor_students();
        }
        private void UpdateTable()
        {
            table.Rows.Clear();
            table.RowCount = Nabor.Students.Count;
            for(int i=0;i<Nabor.Students.Count;i++)
            {
                table.Rows[i].Cells[0].Value = Nabor.Students[i].Number;
                table.Rows[i].Cells[1].Value = Nabor.Students[i].FIO;
                table.Rows[i].Cells[2].Value = Nabor.Students[i].skipped_total;
                table.Rows[i].Cells[3].Value = Nabor.Students[i].skipped_reason;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int number = Convert.ToInt32(textBox1.Text);
            string fio = textBox3.Text;
            int skipped_total = Convert.ToInt32(textBox2.Text);
            int skipped_reason = Convert.ToInt32(textBox4.Text);
            Nabor.DobavitStudenta(number, fio, skipped_total, skipped_reason);
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            UpdateTable();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Nabor.SochranitVFile("Students.dat");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Nabor = Nabor_students.PoluchitNaborIzFile("Students.dat");
            UpdateTable();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int vsego = 0, vsegoUvaszh = 0, vsegoNeuvaszh = 0, postroke = 0;
            for (int i =0; i <Nabor.Students.Count; i++)
            {
                postroke = Nabor.Students[i].skipped_total - Nabor.Students[i].skipped_reason;
                table.Rows[i].Cells[4].Value = postroke;
                vsego += Nabor.Students[i].skipped_total;
                vsegoUvaszh += Nabor.Students[i].skipped_reason;
                vsegoNeuvaszh += postroke;
            }
            int index = table.Rows.Add();
            table.Rows[index].Cells[2].Value = vsego;
            table.Rows[index].Cells[3].Value = vsegoUvaszh;
            table.Rows[index].Cells[4].Value = vsegoNeuvaszh;

        }

        private void button5_Click(object sender, EventArgs e)
        {
            table.Rows.Clear();
        }
    }
}
