﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp46
{
    public partial class Form3 : Form
    {
      
        Nabor_list Nabor1;
        Nabor_skipped Nabor2;
        public Form3()
        {
            InitializeComponent();
            Nabor1 = new Nabor_list();
            Nabor2 = new Nabor_skipped();
        }
        private void Update_Table()
        {
            dataGridView1.Rows.Clear();
            dataGridView1.RowCount = Nabor2.Skipped.Count;
            for(int i=0; i < Nabor2.Skipped.Count; i++)
            {
                dataGridView1.Rows[i].Cells[0].Value = Nabor2.Skipped[i].Code;
                dataGridView1.Rows[i].Cells[1].Value = Nabor2.Skipped[i].Skipped_total;
                dataGridView1.Rows[i].Cells[2].Value = Nabor2.Skipped[i].Skipped_reason;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int code = Convert.ToInt32(textBox1.Text);
            int skipped_total = Convert.ToInt32(textBox2.Text);
            int skipped_reason = Convert.ToInt32(textBox3.Text);
            Nabor2.DobavitOI(code, skipped_total, skipped_reason);
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            Update_Table();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Nabor1.SaveInFile("Skipped.dat");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Nabor1 = Nabor_list.ReadNaborIzFile("Skipped.dat");
            Update_Table();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int i = dataGridView1.SelectedCells[0].RowIndex;
            dataGridView1.Rows.RemoveAt(i);
        }
    }
}
