﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp46
{
    public partial class Form2 : Form
    {
        Nabor_list Nabor;
        public Form2()
        {
            InitializeComponent();
            Nabor = new Nabor_list();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int number = Convert.ToInt32(textBox1.Text);
            string fam_name = textBox2.Text;
            Nabor.DobavitInList(number, fam_name);
            textBox1.Clear();
            textBox2.Clear();
            UpdateTable();
        }
        private void UpdateTable()
        {
            dataGridView1.Rows.Clear();
            dataGridView1.RowCount = Nabor.Students.Count;
            for (int i=0;i<Nabor.Students.Count;i++)
            {
                dataGridView1.Rows[i].Cells[0].Value = Nabor.Students[i].Number;
                dataGridView1.Rows[i].Cells[1].Value = Nabor.Students[i].FIO;
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Nabor.SaveInFile("List.dat");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Nabor = Nabor_list.ReadNaborIzFile("List.dat");
            UpdateTable();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int i = dataGridView1.SelectedRows[0].Index;
            dataGridView1.Rows.RemoveAt(i);
        }
    }
}
