﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp46
{
    [Serializable]
    class OI
    {
        public int Code;
        public int Skipped_total;
        public int Skipped_reason;
        public OI(int code, int skipped_total, int skipped_reason)
        {
            Code = code;
            Skipped_total = skipped_total;
            Skipped_reason = skipped_reason;
        }
    }
}
