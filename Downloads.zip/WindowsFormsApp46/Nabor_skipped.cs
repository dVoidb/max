﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading.Tasks;

namespace WindowsFormsApp46
{
    [Serializable]
    class Nabor_skipped
    {
        public List<OI> Skipped;
        public Nabor_skipped()
        {
            Skipped = new List<OI>();
        }
        public void DobavitOI(int code, int skipped_total, int skipped_reason)
        {
            OI oi = new OI(code, skipped_total, skipped_reason);
            Skipped.Add(oi);
        }
        public void SaveFile(string path)
        {
            FileStream stream = new FileStream(path, FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(stream, this);
            stream.Close();

        }
        public static Nabor_list ReadNaborIzFile(string path)
        {
            Nabor_list nabor;
            FileStream stream = new FileStream(path, FileMode.Open);
            BinaryFormatter formatter = new BinaryFormatter();
            object result_read = formatter.Deserialize(stream);
            nabor = (Nabor_list)result_read;
            stream.Close();
            return nabor;
        }
    }
}
