﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading.Tasks;

namespace WindowsFormsApp46
{
    [Serializable]
    class Nabor_list
    {
     
        public List<List> Students;
        public Nabor_list()
        {
            Students = new List<List>();
        }
        public void DobavitInList(int number, string fio)
        {
            List student = new List(number, fio);
            Students.Add(student);
        }
        public void SaveInFile(string path)
        {
            FileStream stream = new FileStream(path, FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(stream, this);
            stream.Close();
        }
        public static Nabor_list ReadNaborIzFile(string path)
        {
            Nabor_list nabor;
            FileStream stream = new FileStream(path, FileMode.Open);
            BinaryFormatter formatter = new BinaryFormatter();
            nabor = (Nabor_list)formatter.Deserialize(stream);
            stream.Close();
            return nabor;
        }
    }
}
