﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp46
{
    public partial class Form4 : Form
    {
        Nabor_skipped nabor_skipped;
        Nabor_list nabor_list;
        public Form4()
        {
            InitializeComponent();

            nabor_skipped = Nabor_skipped.ReadNaborIzFile("Skipped.dat");
            nabor_list = Nabor_list.ReadNaborIzFile("List.dat");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int skipped_total = 0;
            int skipped_reason = 0;
            int skipped_unreason = 0;
            int neuvaszh = 0;

            for (int i = 0; i < nabor_skipped.Skipped.Count; i++)
            {
                for (int j = 0; j < nabor_list.Students.Count; j++)
                {
                    if (nabor_list.Students[j].Number == nabor_skipped.Skipped[i].Code)
                    {
                        neuvaszh = nabor_skipped.Skipped[i].Skipped_total - nabor_skipped.Skipped[i].Skipped_reason;
                        skipped_reason += nabor_skipped.Skipped[i].Skipped_reason;
                        skipped_unreason += neuvaszh;
                        skipped_total += nabor_skipped.Skipped[i].Skipped_total;
                        dataGridView1.Rows.Add
                        (
                        nabor_list.Students[j].Number,
                        nabor_list.Students[j].FIO,
                        nabor_skipped.Skipped[i].Skipped_total, nabor_skipped.Skipped[i].Skipped_reason, neuvaszh
                       );

                    }
                }

            }
            int index = dataGridView1.Rows.Add();
            dataGridView1.Rows[index].Cells[2].Value = skipped_total;
            dataGridView1.Rows[index].Cells[3].Value = skipped_reason;
            dataGridView1.Rows[index].Cells[4].Value = skipped_unreason;
        }
    }
}
