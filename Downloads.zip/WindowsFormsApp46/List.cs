﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp46
{
    [Serializable]
    class List
    {
        public int Number;
        public string FIO;
        public List(int number, string fIO)
        {
            Number = number;
            FIO = fIO;
        }
    }
}
