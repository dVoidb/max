﻿// Task1.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <cmath>

using namespace std;

double task1(int &b, double &a);
double task2(double &a,double &b);
double task3(int& b, int& a);
double task4(int& b, int& a);
double task5(int& a, double& b);

int main()
{
    setlocale(LC_ALL, "RUS");

    #pragma region Задание №1
    try
    {
        double field1;
        int field2;
        cout << "Введите значение для field1" << endl;
        cin >> field1;
        cout << "Введите значение для field2" << endl;
        cin >> field2;

        cout << "Ответ:" << task1(field2, field1) << endl;
    }
    catch (const std::exception&)
    {
        cout << "Ошибка входных данных" << endl;
    }
   #pragma endregion Задание №1
   
    #pragma region Задание №2
    try
    {
        double field1, field2;
        cout << "Введите значение для field1" << endl;
        cin >> field1;
        cout << "Введите значение для field2" << endl;
        cin >> field2;

        cout << "Ответ:" << task2(field2, field1) << endl;
    }
    catch (const std::exception&)
    {
        cout << "Ошибка входных данных" << endl;
    }
    #pragma endregion Задание №2

    #pragma region Задание №3
    try
    {
        int field1, field2;
        cout << "Введите значение для field1" << endl;
        cin >> field1;
        cout << "Введите значение для field2" << endl;
        cin >> field2;

        cout << "Ответ:" << task3(field2, field1) << endl;
    }
    catch (const std::exception&)
    {
        cout << "Ошибка входных данных" << endl;
    }
#pragma endregion Задание №3

    #pragma region Задание №4
    try
    {
        int field1, field2;
        cout << "Введите номинал купюры" << endl;
        cin >> field1;
        cout << "Введите количество купюр" << endl;
        cin >> field2;
        if(field1==50&& field1 == 100 && field1 == 500 && field1 == 1000 && field1 == 2000 && field1 == 5000 )
        {
            cout << "Ответ:" << task4(field2, field1) << endl;
        }
        else
        {
            cout << "Неправильный номинал купюры" << endl;
        }
    }
    catch (const std::exception&)
    {
        cout << "Ошибка входных данных" << endl;
    }
#pragma endregion Задание №4

    #pragma region Задание №5
    try
    {
        int field1;double field2;
        cout << "Введите цену товара" << endl;
        cin >> field1;
        cout << "Введите количество единиц товара" << endl;
        cin >> field2;
        if (field1>0&& field2>0)
        {
            cout << "Ответ:" << task5(field1, field2) << endl;
        }
        else
        {
            cout << "Число не может быть отрицательным" << endl;
        }
    }
    catch (const std::exception&)
    {
        cout << "Ошибка входных данных" << endl;
    }
#pragma endregion Задание №5
}


double task1(int &b, double &a)
{
    return pow(b,a);
}
double task2(double& b, double& a)
{
    return pow(b, a);
}
double task3(int& b, int& a)
{
    return trunc(a/b);
}
double task4(int& b, int& a)
{
    return a*b;
}
double task5(int& a, double& b)
{
    return a * b;
}